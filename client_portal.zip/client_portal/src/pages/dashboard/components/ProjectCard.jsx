import React from 'react';
import { Link } from 'react-router-dom';
import Icon from 'components/AppIcon';

const ProjectCard = ({ project }) => {
  const getStatusColor = (status) => {
    switch (status) {
      case 'Completed':
        return 'bg-jabv-success text-white';
      case 'In Progress':
        return 'bg-jabv-progress text-white';
      case 'Client Review':
        return 'bg-jabv-review text-white';
      case 'Pending':
        return 'bg-jabv-pending text-white';
      default:
        return 'bg-jabv-pending text-white';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'Completed':
        return 'CheckCircle';
      case 'In Progress':
        return 'Clock';
      case 'Client Review':
        return 'Eye';
      case 'Pending':
        return 'Pause';
      default:
        return 'Circle';
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <Link
      to="/project-details"
      className="block bg-jabv-light-bg rounded-xl border border-border hover:border-jabv-primary hover:shadow-card-hover transition-smooth duration-300 group"
    >
      <div className="p-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-jabv-dark-text group-hover:text-jabv-primary transition-smooth mb-1 font-heading">
              {project.name}
            </h3>
            <p className="text-sm text-text-secondary font-body">{project.clientCompany}</p>
          </div>
          <div className={`inline-flex items-center space-x-1 px-3 py-1 rounded-full text-xs font-medium font-body ${getStatusColor(project.status)}`}>
            <Icon name={getStatusIcon(project.status)} size={12} />
            <span>{project.status}</span>
          </div>
        </div>

        {/* Description */}
        <p className="text-sm text-text-secondary mb-4 line-clamp-2 font-body">
          {project.description}
        </p>

        {/* Progress Bar */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-jabv-dark-text font-heading">Progress</span>
            <span className="text-sm text-text-secondary font-body">{project.progress}%</span>
          </div>
          <div className="w-full bg-background rounded-full h-2">
            <div
              className="progress-bar-jabv h-2 rounded-full transition-smooth duration-500"
              style={{ width: `${project.progress}%`, backgroundColor: '#ADFF2F' }}
            ></div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between text-xs text-text-secondary font-body">
          <div className="flex items-center space-x-1">
            <Icon name="Calendar" size={12} />
            <span>{formatDate(project.startDate)}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Icon name="Target" size={12} />
            <span>{formatDate(project.endDate)}</span>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default ProjectCard;